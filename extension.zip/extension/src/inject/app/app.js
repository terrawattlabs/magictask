'use strict';

angular.module("app", ["ui.bootstrap"]);